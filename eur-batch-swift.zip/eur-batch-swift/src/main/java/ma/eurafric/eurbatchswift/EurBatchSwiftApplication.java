package ma.eurafric.eurbatchswift;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurBatchSwiftApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurBatchSwiftApplication.class, args);
	}

}
