package ma.eurafric.eurbatchswift.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ma.eurafric.eurbatchswift.entities.TypeSwift;

public interface TypeSwiftRepository extends JpaRepository<TypeSwift, Integer> {

}
