package ma.eurafric.eurbatchswift.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ma.eurafric.eurbatchswift.entities.Swift;

public interface SwiftRepository extends JpaRepository<Swift, Integer> {

}
