-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3345
-- Généré le : jeu. 25 mars 2021 à 12:20
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `eurafric-swift-batch`
--

-- --------------------------------------------------------

--
-- Structure de la table `type_champ`
--

CREATE TABLE `type_champ` (
  `id_type_champ` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `id_type_swift` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `type_champ`
--

INSERT INTO `type_champ` (`id_type_champ`, `description`, `libelle`, `id_type_swift`) VALUES
(1, 'sender\'s reference', '20', 4),
(2, 'time indication', '13C', 4),
(3, 'Bank Operation Code', '23B', 4),
(4, 'Instruction Code', '23E', 4),
(5, 'Transaction Type Code', '26T', 4),
(6, 'Value Date/Currency/Interbank Settled Amount', '32A', 4),
(7, 'Currency/Instructed Amount', '33B', 4),
(8, 'Exchange Rate', '36', 4),
(9, 'Ordering Customer', '50A', 4),
(10, 'Ordering Customer', '50F', 4),
(11, 'Ordering Customer', '50K', 4),
(12, 'Sending Institution', '51A\r\n', 4),
(13, 'Sending Institution', '51K\r\n', 4),
(14, 'Sending Institution', '51F\r\n', 4),
(15, 'Ordering Institution', '52A', 4),
(16, 'Ordering Institution', '52D', 4),
(17, 'Sender\'s Correspondent', '53A', 4),
(18, 'Sender\'s Correspondent', '53B', 4),
(19, 'Sender\'s Correspondent', '53D', 4),
(20, 'Receiver\'s Correspondent', '54A', 4),
(21, 'Receiver\'s Correspondent', '54B', 4),
(22, 'Receiver\'s Correspondent', '54D', 4),
(23, 'Third Reimbursement Institution', '55A', 4),
(24, 'Third Reimbursement Institution', '55B', 4),
(25, 'Third Reimbursement Institution', '55D', 4),
(26, 'Intermediary Institution', '56A', 4),
(27, 'Intermediary Institution', '56C', 4),
(28, 'Intermediary Institution', '56D', 4),
(29, 'Account With Institution', '57A', 4),
(30, 'Account With Institution', '57B', 4),
(31, 'Account With Institution', '57C', 4),
(32, 'Account With Institution', '57D', 4),
(33, 'Beneficiary Customer', '59A', 4),
(34, 'Beneficiary Customer', '59F', 4),
(35, 'Remittance Information', '70', 4),
(36, 'Details of Charges', '71A', 4),
(37, 'Sender\'s Charges', '71F', 4),
(38, 'Receiver\'s Charges', '71G', 4),
(39, 'Sender to Receiver Information', '72', 4),
(40, 'Regulatory Reporting', '77B', 4),
(41, 'Transaction Reference Number', '20\r\n\r\n', 22),
(42, 'Related Reference', '21', 22),
(43, 'Time Indication', '13C', 22),
(44, 'Value Date, Currency Code, Amount', '32A', 22),
(45, 'Ordering Institution', '52A', 22),
(46, 'Ordering Institution', '52D', 22),
(47, 'Sender\'s Correspondent', '53A', 22),
(48, 'Sender\'s Correspondent', '53B', 22),
(49, 'Sender\'s Correspondent', '53D', 22),
(50, 'Receiver\'s Correspondent', '54A', 22),
(51, 'Receiver\'s Correspondent', '54B', 22),
(52, 'Receiver\'s Correspondent', '54D', 22),
(53, 'Intermediary', '56A', 22),
(54, 'Intermediary', '56D', 22),
(55, 'Account With Institution', '57A', 22),
(56, 'Account With Institution', '57B', 22),
(57, 'Account With Institution', '57D', 22),
(58, 'Beneficiary Institution', '58A', 22),
(59, 'Beneficiary Institution', '58D', 22),
(60, 'Sender to Receiver Information', '72', 22),
(61, 'Sequence of Total', '27', 161),
(62, 'Form of Documentary Credit', '40A', 161),
(63, 'Documentary Credit Number', '20', 161),
(64, 'Reference to Pre-Advice', '23', 161),
(65, 'Date of Issue', '31C', 161),
(66, 'Applicable Rules', '40E', 161),
(67, 'Date and Place of Expiry', '31D', 161),
(68, 'Applicant Bank', '51A', 161),
(69, 'Applicant Bank', '51D', 161),
(70, 'Applicant', '50', 161),
(71, 'Beneficiary', '59', 161),
(72, 'Currency Code, Amount', '32B', 161),
(73, 'Percentage Credit Amount Tolerance', '39A', 161),
(74, 'Maximum Credit Amount', '39B', 161),
(75, 'Additional Amounts Covered', '39C', 161),
(76, 'Available With ... By ...', '41A', 161),
(77, 'Available With ... By ...', '41D', 161),
(78, 'Drafts at ...', '42C', 161),
(79, 'Drawee', '42A', 161),
(80, 'Drawee', '42D', 161),
(81, 'Mixed Payment Details', '42M', 161),
(82, 'Deferred Payment Details', '42P', 161),
(83, 'Partial Shipments', '43P', 161),
(84, 'Transshipment', '43T', 161),
(85, 'Place of Taking in Charge/Dispatch from .../Place of Receipt', '44A', 161),
(86, 'Port of Loading/Airport of Departure', '44E', 161),
(87, 'Port of Discharge/Airport of Destination', '44F', 161),
(88, 'Place of Final Destination/For Transportation to .../Place of Delivery', '44B', 161),
(89, 'Latest Date of Shipment', '44C', 161),
(90, 'Shipment Period', '44D', 161),
(91, 'Description of Goods and/or Services', '45A', 161),
(92, 'Documents Required', '46A', 161),
(93, 'Additional Conditions', '47A', 161),
(94, 'Charges', '71B', 161),
(95, 'Period for Presentation', '48', 161),
(96, 'Confirmation Instructions', '49', 161),
(97, 'Reimbursing Bank', '53A', 161),
(98, 'Reimbursing Bank', '53D', 161),
(99, 'Instructions to the Paying/Accepting/Negotiating Bank', '78', 161),
(100, '\'Advise Through\' Bank', '57A', 161),
(101, '\'Advise Through\' Bank', '57B', 161),
(102, '\'Advise Through\' Bank', '57D', 161),
(103, 'Sender to Receiver Information', '72', 161),
(104, 'Sending Bank\'s TRN', '20', 63),
(105, 'Related Reference', '21', 63),
(106, 'Amount Collected', '32A', 63),
(107, 'Amount Collected', '32B', 63),
(108, 'Amount Collected', '32K', 63),
(109, 'Proceeds Remitted', '33A', 63),
(110, 'Ordering Bank', '52A', 63),
(111, 'Ordering Bank', '52D', 63),
(112, 'Sender\'s Correspondent', '53A', 63),
(113, 'Sender\'s Correspondent', '53B', 63),
(114, 'Sender\'s Correspondent', '53D', 63),
(115, 'Receiver\'s Correspondent', '54A', 63),
(116, 'Receiver\'s Correspondent', '54B', 63),
(117, 'Receiver\'s Correspondent', '54D', 63),
(118, 'Account With Bank', '57A', 63),
(119, 'Account With Bank', '57D', 63),
(120, 'Beneficiary Bank', '58A', 63),
(121, 'Beneficiary Bank', '58B', 63),
(122, 'Beneficiary Bank', '58D', 63),
(123, 'Details of Charges', '71B', 63),
(124, 'Sender to Receiver Information', '72', 63),
(125, 'Details of Amounts Added', '73', 63),
(126, 'sender to receiver information ', '72Z', 161),
(127, 'charges', '71D', 161);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `type_champ`
--
ALTER TABLE `type_champ`
  ADD PRIMARY KEY (`id_type_champ`),
  ADD KEY `FKgdtgo2dn986rjy2c5dniyaoun` (`id_type_swift`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `type_champ`
--
ALTER TABLE `type_champ`
  MODIFY `id_type_champ` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
