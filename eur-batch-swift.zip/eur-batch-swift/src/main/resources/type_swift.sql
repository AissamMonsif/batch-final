-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3345
-- Généré le : jeu. 25 mars 2021 à 12:50
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `eurafric-swift-batch`
--

-- --------------------------------------------------------

--
-- Structure de la table `type_swift`
--

CREATE TABLE `type_swift` (
  `id_type_swift` int(11) NOT NULL,
  `categorie` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `type_swift`
--

INSERT INTO `type_swift` (`id_type_swift`, `categorie`, `designation`, `libelle`) VALUES
(1, 'Virements clients et Chèques', 'Demande de transfert', 'MT101'),
(2, 'Virements clients et Chèques', 'Virement à plusieurs clients', 'MT102'),
(3, 'Virements clients et Chèques', 'Virement à plusieurs clients', 'MT102.STP'),
(4, 'Virements clients et Chèques', 'Virement à un client', 'MT103'),
(5, 'Virements clients et Chèques', 'Virement à un client', 'MT103.REMIT'),
(6, 'Virements clients et Chèques', 'Virement à un client', 'MT103.STP'),
(7, 'Virements clients et Chèques', 'Recouvrement direct', 'MT104'),
(8, 'Virements clients et Chèques', 'Enveloppe EDIFACT', 'MT105'),
(9, 'Virements clients et Chèques', 'Avis général direct de débit', 'MT107'),
(10, 'Virements clients et Chèques', 'Avis de tirage de chèque', 'MT110'),
(11, 'Virements clients et Chèques', 'Demande d\'opposition sur un chèque', 'MT111'),
(12, 'Virements clients et Chèques', 'Réponse à une demande d\'opposition sur un chèque', 'MT112'),
(13, 'Virements clients et Chèques', 'Avis de charges, intérêts et autres ajustements', 'MT190'),
(14, 'Virements clients et Chèques', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT191'),
(15, 'Virements clients et Chèques', 'Demande d\'annulation', 'MT192'),
(16, 'Virements clients et Chèques', 'Requête', 'MT195'),
(17, 'Virements clients et Chèques', 'Réponse', 'MT196'),
(18, 'Virements clients et Chèques', 'Message propriétaire', 'MT198'),
(19, 'Virements clients et Chèques', 'Message à format libre', 'MT199'),
(20, 'Virements entre institutions financières', 'Virement interbancaire pour compte propre', 'MT200'),
(21, 'Virements entre institutions financières', 'Virements interbancaires multiples pour compte propre', 'MT201'),
(22, 'Virements entre institutions financières', 'Virement interbancaire', 'MT202'),
(23, 'Virements entre institutions financières', 'Virement interbancaire', 'MT202.COV'),
(24, 'Virements entre institutions financières', 'Virements interbancaires multiples', 'MT203'),
(25, 'Virements entre institutions financières', 'Message de débit direct marchés financiers', 'MT204'),
(26, 'Virements entre institutions financières', 'Exécution d\'un virement interbancaire', 'MT205'),
(27, 'Virements entre institutions financières', 'Exécution d\'un virement interbancaire', 'MT205.COV'),
(28, 'Virements entre institutions financières', 'Demande de virement interbancaire', 'MT207'),
(29, 'Virements entre institutions financières', 'Avis de réception', 'MT210'),
(30, 'Virements entre institutions financières', 'Avis de non-paiement de chèque', 'MT256'),
(31, 'Virements entre institutions financières', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT291'),
(32, 'Virements entre institutions financières', 'Demande d\'annulation', 'MT292'),
(33, 'Virements entre institutions financières', 'Requête', 'MT295'),
(34, 'Virements entre institutions financières', 'Réponse', 'MT296'),
(35, 'Virements entre institutions financières', 'Message propriétaire', 'MT298'),
(36, 'Virements entre institutions financières', 'Message à format libre', 'MT299'),
(37, 'Change, marché monétaire et dérivés', 'Confirmation d\'une opération de change', 'MT300'),
(38, 'Change, marché monétaire et dérivés', 'Forex/Currency Option Allocation Instruction', 'MT303'),
(39, 'Change, marché monétaire et dérivés', 'Confirmation d\'une opération d\'option de change', 'MT305'),
(40, 'Change, marché monétaire et dérivés', 'Confirmation d\'une opération d\'option de change', 'MT306'),
(41, 'Change, marché monétaire et dérivés', 'Advice/Instruction of a Third Party FX Deal', 'MT307'),
(42, 'Change, marché monétaire et dérivés', 'Confirmation d\'un emprunt/dépôt à durée fixe', 'MT320'),
(43, 'Change, marché monétaire et dérivés', 'Instruction to Settle a Third Party Loan/Deposit', 'MT321'),
(44, 'Change, marché monétaire et dérivés', 'Confirmation d\'un emprunt/dépôt à durée variable', 'MT330'),
(45, 'Change, marché monétaire et dérivés', 'Confirmation de FRA', 'MT340'),
(46, 'Change, marché monétaire et dérivés', 'Confirmation de règlement de FRA', 'MT341'),
(47, 'Change, marché monétaire et dérivés', 'Avis de paiement d\'intérêts sur emprunt/dépôt', 'MT350'),
(48, 'Change, marché monétaire et dérivés', 'Single Currency Interest Rate Derivative Confirmation', 'MT360'),
(49, 'Change, marché monétaire et dérivés', 'Cross Currency Interest Rate Swap Confirmation', 'MT361'),
(50, 'Change, marché monétaire et dérivés', 'Interest Rate Reset/Advice of Payment', 'MT362'),
(51, 'Change, marché monétaire et dérivés', 'Single Currency Interest Rate Derivative Termination/Recouponing Confirmation', 'MT364'),
(52, 'Change, marché monétaire et dérivés', 'Cross Currency Interest Rate Swap Termination/Recouponing Confirmation', 'MT365'),
(53, 'Change, marché monétaire et dérivés', 'Netting Position Advice', 'MT370'),
(54, 'Change, marché monétaire et dérivés', 'Foreign Exchange Order', 'MT380'),
(55, 'Change, marché monétaire et dérivés', 'Foreign Exchange Order Confirmation', 'MT381'),
(56, 'Change, marché monétaire et dérivés', 'Avis de charges, intérêts et autres ajustements', 'MT390'),
(57, 'Change, marché monétaire et dérivés', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT391'),
(58, 'Change, marché monétaire et dérivés', 'Demande d\'annulation', 'MT392'),
(59, 'Change, marché monétaire et dérivés', 'Requête', 'MT395'),
(60, 'Change, marché monétaire et dérivés', 'Réponse', 'MT396'),
(61, 'Change, marché monétaire et dérivés', 'Message propriétaire', 'MT398'),
(62, 'Change, marché monétaire et dérivés', 'Message à format libre', 'MT399'),
(63, 'Encaissements et Lettres de crédit', 'Avis de paiement', 'MT400'),
(64, 'Encaissements et Lettres de crédit', 'Acknowledgement	Utilisation Scope Structure', 'MT410'),
(65, 'Encaissements et Lettres de crédit', 'Avis d\'acceptation', 'MT412'),
(66, 'Encaissements et Lettres de crédit', 'Advice of Non-Payment/Non-Acceptance', 'MT416'),
(67, 'Encaissements et Lettres de crédit', 'Tracer', 'MT420'),
(68, 'Encaissements et Lettres de crédit', 'Advice of Fate and Request for Instructions', 'MT422'),
(69, 'Encaissements et Lettres de crédit', 'Amendment of Instructions', 'MT430'),
(70, 'Encaissements et Lettres de crédit', 'Cash Letter Credit Advice', 'MT450'),
(71, 'Encaissements et Lettres de crédit', 'Advice of Dishonour', 'MT456'),
(72, 'Encaissements et Lettres de crédit', 'Avis de charges, intérêts et autres ajustements', 'MT490'),
(73, 'Encaissements et Lettres de crédit', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT491'),
(74, 'Encaissements et Lettres de crédit', 'Demande d\'annulation', 'MT492'),
(75, 'Encaissements et Lettres de crédit', 'Requête', 'MT495'),
(76, 'Encaissements et Lettres de crédit', 'Réponse', 'MT496'),
(77, 'Encaissements et Lettres de crédit', 'Message propriétaire', 'MT498'),
(78, 'Encaissements et Lettres de crédit', 'Message à format libres', 'MT499'),
(79, 'Marchés des titres', 'Instruction d\'enregistrement', 'MT500'),
(80, 'Marchés des titres', 'Confirmation of Registration or Modification', 'MT501'),
(81, 'Marchés des titres', 'Ordre d\'achat ou de vente', 'MT502'),
(82, 'Marchés des titres', 'Collateral Claim', 'MT503'),
(83, 'Marchés des titres', 'Collateral Proposal', 'MT504'),
(84, 'Marchés des titres', 'Collateral Substitution', 'MT505'),
(85, 'Marchés des titres', 'Collateral and Exposure Statement', 'MT506'),
(86, 'Marchés des titres', 'Collateral Status and Processing Advice', 'MT507'),
(87, 'Marchés des titres', 'Intra-Position Advice', 'MT508'),
(88, 'Marchés des titres', 'Message de statut d\'un ordre', 'MT509'),
(89, 'Marchés des titres', 'Registration Status and Processing Advice', 'MT510'),
(90, 'Marchés des titres', 'Client Advice Of Execution', 'MT513'),
(91, 'Marchés des titres', 'Trade Allocation Instruction', 'MT514'),
(92, 'Marchés des titres', 'Confirmation d\'achat ou de vente au client', 'MT515'),
(93, 'Marchés des titres', 'Confirmation d\'un prêt de titres', 'MT516'),
(94, 'Marchés des titres', 'Affirmation de la confirmation d\'une transaction', 'MT517'),
(95, 'Marchés des titres', 'Confirmation d\'une transaction sur titres entre participants de marché', 'MT518'),
(96, 'Marchés des titres', 'Modification de données clients', 'MT519'),
(97, 'Marchés des titres', 'Intra-Position Instruction', 'MT524'),
(98, 'Marchés des titres', 'General Securities Lending/Borrowing Message', 'MT526'),
(99, 'Marchés des titres', 'Triparty Collateral Instruction', 'MT527'),
(100, 'Marchés des titres', 'Transaction Processing Command', 'MT530'),
(101, 'Marchés des titres', 'Relevé de compte-titres', 'MT535'),
(102, 'Marchés des titres', 'Statement of Transactions', 'MT536'),
(103, 'Marchés des titres', 'Statement of Pending Transactions', 'MT537'),
(104, 'Marchés des titres', 'Statement of Intra-Position Advices', 'MT538'),
(105, 'Marchés des titres', 'Instruction de réception de titres franco', 'MT540'),
(106, 'Marchés des titres', 'Instruction de réception de titres contre paiement', 'MT541'),
(107, 'Marchés des titres', 'Instruction de livraison de titres franco', 'MT542'),
(108, 'Marchés des titres', 'Instruction de livraision de titres contre paiement', 'MT543'),
(109, 'Marchés des titres', 'Confirmation de réception de titres franco', 'MT544'),
(110, 'Marchés des titres', 'Confirmation de réception de titres contre paiement', 'MT545'),
(111, 'Marchés des titres', 'Confirmation de livraison de titres franco', 'MT546'),
(112, 'Marchés des titres', 'Confirmation de livraison de titres contre paiement', 'MT547'),
(113, 'Marchés des titres', 'Statut de dénouement et d\'avis de traitement', 'MT548'),
(114, 'Marchés des titres', 'Request for Statement/Status Advice', 'MT549'),
(115, 'Marchés des titres', 'Triparty Collateral Status and Processing Advice', 'MT558'),
(116, 'Marchés des titres', 'Paying Agent\'s Claims', 'MT559'),
(117, 'Marchés des titres', 'Corporate Action Notification', 'MT564'),
(118, 'Marchés des titres', 'Corporate Action Instruction', 'MT565'),
(119, 'Marchés des titres', 'Corporate Action Confirmation', 'MT566'),
(120, 'Marchés des titres', 'Corporate Action Status and Processing Advice', 'MT567'),
(121, 'Marchés des titres', 'Corporate Action Narrative', 'MT568'),
(122, 'Marchés des titres', 'Triparty Collateral and Exposure Statement', 'MT569'),
(123, 'Marchés des titres', 'IRS 1441 NRA-IRS Beneficial Owners\' List', 'MT574.IRSLST'),
(124, 'Marchés des titres', 'IRS 1441 NRA-Form W8-BEN', 'MT574.W8BENO'),
(125, 'Marchés des titres', 'Report of Combined Activity', 'MT575'),
(126, 'Marchés des titres', 'Statement of Open Orders', 'MT576'),
(127, 'Marchés des titres', 'Statement of Numbers', 'MT577'),
(128, 'Marchés des titres', 'Relance d\'appariement', 'MT578'),
(129, 'Marchés des titres', 'Certificate Numbers', 'MT579'),
(130, 'Marchés des titres', 'Collateral Adjustment Message', 'MT581'),
(131, 'Marchés des titres', 'Statement of Settlement Allegements', 'MT586'),
(132, 'Marchés des titres', 'Avis de charges, intérêts et autres ajustements', 'MT590'),
(133, 'Marchés des titres', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT591'),
(134, 'Marchés des titres', 'Demande d\'annulation', 'MT592'),
(135, 'Marchés des titres', 'Requête', 'MT595'),
(136, 'Marchés des titres', 'Réponse', 'MT596'),
(137, 'Marchés des titres', 'Message propriétaire', 'MT598'),
(138, 'Marchés des titres', 'Message à format libre', 'MT599'),
(139, 'Métaux précieux et syndication', 'Commodity Trade Confirmation', 'MT600'),
(140, 'Métaux précieux et syndication', 'Commodity Option Confirmation', 'MT601'),
(141, 'Métaux précieux et syndication', 'Commodity Transfer/Delivery Order', 'MT604'),
(142, 'Métaux précieux et syndication', 'Commodity Notice to Receive', 'MT605'),
(143, 'Métaux précieux et syndication', 'Commodity Debit Advice', 'MT606'),
(144, 'Métaux précieux et syndication', 'Commodity Credit Advice', 'MT607'),
(145, 'Métaux précieux et syndication', 'Statement of a Commodity Account', 'MT608'),
(146, 'Métaux précieux et syndication', 'Statement of Commodity Contracts', 'MT609'),
(147, 'Métaux précieux et syndication', 'Commodity Fixed Loan/Deposit Confirmation', 'MT620'),
(148, 'Métaux précieux et syndication', 'Notice of Drawdown/Renewal', 'MT643'),
(149, 'Métaux précieux et syndication', 'Advice of Rate and Amount Fixing', 'MT644'),
(150, 'Métaux précieux et syndication', 'Payment of Principal and/or of Interest', 'MT646'),
(151, 'Métaux précieux et syndication', 'General Syndicated Facility Message', 'MT649'),
(152, 'Métaux précieux et syndication', 'Standing Settlement Instruction Update Notification Request', 'MT670'),
(153, 'Métaux précieux et syndication', 'Standing Settlement Instruction Update Notification', 'MT671'),
(154, 'Métaux précieux et syndication', 'Avis de charges, intérêts et autres ajustements', 'MT690'),
(155, 'Métaux précieux et syndication', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT691'),
(156, 'Métaux précieux et syndication', 'Demande d\'annulation', 'MT692'),
(157, 'Métaux précieux et syndication', 'Requête', 'MT695'),
(158, 'Métaux précieux et syndication', 'Réponse', 'MT695'),
(159, 'Métaux précieux et syndication', 'Message propriétaire', 'MT698'),
(160, 'Métaux précieux et syndication', 'Message à format libre', 'MT699'),
(161, 'Crédits documentaires et Garanties', 'Ouverture de crédit documentaire', 'MT700'),
(162, 'Crédits documentaires et Garanties', 'Ouverture de crédit documentaire', 'MT701'),
(163, 'Crédits documentaires et Garanties', 'Préavis de crédit documentaire', 'MT705'),
(164, 'Crédits documentaires et Garanties', 'Modification de crédit documentaire', 'MT707'),
(165, 'Crédits documentaires et Garanties', 'Notification de crédit documentaire d\'une tierce banque', 'MT710'),
(166, 'Crédits documentaires et Garanties', 'Notification de crédit documentaire d\'une tierce banque', 'MT711'),
(167, 'Crédits documentaires et Garanties', 'Transfert de crédit documentaire', 'MT720'),
(168, 'Crédits documentaires et Garanties', 'Transfert de crédit documentaire', 'MT721'),
(169, 'Crédits documentaires et Garanties', 'Accusé de réception', 'MT730'),
(170, 'Crédits documentaires et Garanties', 'Avis de décharge', 'MT732'),
(171, 'Crédits documentaires et Garanties', 'Avis de refus', 'MT734'),
(172, 'Crédits documentaires et Garanties', 'Autorisation de remboursement', 'MT740'),
(173, 'Crédits documentaires et Garanties', 'Demande de remboursement', 'MT742'),
(174, 'Crédits documentaires et Garanties', 'Modification d’une autorisation de remboursement', 'MT747'),
(175, 'Crédits documentaires et Garanties', 'Avis d’irrégularité', 'MT750'),
(176, 'Crédits documentaires et Garanties', 'Autorisation de paiement/acceptation/négociation', 'MT752'),
(177, 'Crédits documentaires et Garanties', 'Avis de paiement/acceptation/négociation', 'MT754'),
(178, 'Crédits documentaires et Garanties', 'Avis de remboursement/paiement', 'MT756'),
(179, 'Crédits documentaires et Garanties', 'Émission d’une garantie', 'MT760'),
(180, 'Crédits documentaires et Garanties', 'Modification d’une garantie', 'MT767'),
(181, 'Crédits documentaires et Garanties', 'Accusé de réception d’un message de garantie', 'MT768'),
(182, 'Crédits documentaires et Garanties', 'Mainlevée totale ou partielle sur une garantie', 'MT769'),
(183, 'Crédits documentaires et Garanties', 'Avis de charges, intérêts et autres ajustements', 'MT790'),
(184, 'Crédits documentaires et Garanties', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT791'),
(185, 'Crédits documentaires et Garanties', 'Demande d\'annulation', 'MT792'),
(186, 'Crédits documentaires et Garanties', 'Requête', 'MT795'),
(187, 'Crédits documentaires et Garanties', 'Réponse', 'MT796'),
(188, 'Crédits documentaires et Garanties', 'Message propriétaire', 'MT798'),
(189, 'Crédits documentaires et Garanties', 'Message à format libre', 'MT799'),
(190, 'Chèques de voyage', 'T/C Sales and Settlement Advice [Single]', 'MT800'),
(191, 'Chèques de voyage', 'T/C Multiple Sales Advice', 'MT801'),
(192, 'Chèques de voyage', 'T/C Settlement Advice', 'MT802'),
(193, 'Chèques de voyage', 'T/C Inventory Destruction/Cancellation Notice', 'MT824'),
(194, 'Chèques de voyage', 'Avis de charges, intérêts et autres ajustements', 'MT890'),
(195, 'Chèques de voyage', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT891'),
(196, 'Chèques de voyage', 'Demande d\'annulation', 'MT892'),
(197, 'Chèques de voyage', 'Requête', 'MT895'),
(198, 'Chèques de voyage', 'Réponse', 'MT896'),
(199, 'Chèques de voyage', 'Message propriétaire', 'MT898'),
(200, 'Chèques de voyage', 'Message à format libre', 'MT899'),
(201, 'Gestion de trésorerie et Restitutions clients', 'Confirmation de débit', 'MT900'),
(202, 'Gestion de trésorerie et Restitutions clients', 'Confirmation de crébit', 'MT910'),
(203, 'Gestion de trésorerie et Restitutions clients', 'Message de demande', 'MT920'),
(204, 'Gestion de trésorerie et Restitutions clients', 'Avis de modification de taux', 'MT935'),
(205, 'Gestion de trésorerie et Restitutions clients', 'Extrait de compte client', 'MT940'),
(206, 'Gestion de trésorerie et Restitutions clients', 'Rapport de solde', 'MT941'),
(207, 'Gestion de trésorerie et Restitutions clients', 'Relevé provisoire d’opérations', 'MT942'),
(208, 'Gestion de trésorerie et Restitutions clients', 'Extraits de compte correspondant', 'MT950'),
(209, 'Gestion de trésorerie et Restitutions clients', 'Extrait de compte de netting', 'MT970'),
(210, 'Gestion de trésorerie et Restitutions clients', 'Rapport de solde sur netting', 'MT971'),
(211, 'Gestion de trésorerie et Restitutions clients', 'Extrait de compte de netting intermédiaire', 'MT972'),
(212, 'Gestion de trésorerie et Restitutions clients', 'Demande de rapport de netting', 'MT973'),
(213, 'Gestion de trésorerie et Restitutions clients', 'Status Enquiry', 'MT985'),
(214, 'Gestion de trésorerie et Restitutions clients', 'Status Report', 'MT986'),
(215, 'Gestion de trésorerie et Restitutions clients', 'Avis de charges, intérêts et autres ajustements', 'MT990'),
(216, 'Gestion de trésorerie et Restitutions clients', 'Demande de paiements de charges, intérêts et autres dépenses', 'MT991'),
(217, 'Gestion de trésorerie et Restitutions clients', 'Demande d\'annulation', 'MT992'),
(218, 'Gestion de trésorerie et Restitutions clients', 'Requête', 'MT995'),
(219, 'Gestion de trésorerie et Restitutions clients', 'Réponse', 'MT996'),
(220, 'Gestion de trésorerie et Restitutions clients', 'Message propriétaire', 'MT998'),
(221, 'Gestion de trésorerie et Restitutions clients', 'Message à format libre', 'MT999');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `type_swift`
--
ALTER TABLE `type_swift`
  ADD PRIMARY KEY (`id_type_swift`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `type_swift`
--
ALTER TABLE `type_swift`
  MODIFY `id_type_swift` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
